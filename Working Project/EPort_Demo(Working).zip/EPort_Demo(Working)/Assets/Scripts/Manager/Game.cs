﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Game : MonoBehaviour {
	
	public GameObject m_Player;
	public GameObject m_PauseMenuUI;

	void Update () {
		if(m_Player.GetComponent<PlayerHealth>().getIfDead()){
			StartCoroutine(WaitForExplosion());
		}
		if(Input.GetButtonDown("Quit")){
			QuitGame();
		}
	}

	private IEnumerator WaitForExplosion(){
		yield return new WaitForSeconds(4f);
		CallMenu();
	}

	private void CallMenu(){
		Time.timeScale = 0f;
		m_PauseMenuUI.SetActive(true);
	}

	public void QuitGame(){
		Application.Quit();
	}

	public void StartNew(){
		m_PauseMenuUI.SetActive(false);
		Time.timeScale = 1f;
		SceneManager.LoadScene("Demo");
	}
}
