﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boundaries : MonoBehaviour {

	public GameObject m_Player;
	public GameObject m_Warning;
	public float m_DamageOverTime = 0.1f;
	
	private bool m_OutOfZone = false;

	void Update(){
		if(m_OutOfZone){
			m_Player.GetComponent<PlayerHealth>().TakeDamage(m_DamageOverTime);
		}
	}

	void OnTriggerEnter(Collider col){
		if(col.gameObject.tag == "Player"){
			m_OutOfZone = false;
			m_Warning.SetActive(false);
		}
	}

	void OnTriggerExit(Collider col){
		if(col.gameObject.tag == "Player"){
			m_OutOfZone = true;
			m_Warning.SetActive(true);
		}
	}
}
