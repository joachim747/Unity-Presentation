﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Planets : MonoBehaviour {

	private Transform parent;

	void Start(){
		parent = transform.parent.gameObject.transform;
	}

	void OnTriggerEnter(Collider other){
		if(other.gameObject.tag == "Player"){
			other.gameObject.GetComponent<PlayerHealth>().TakeDamage(100f);
		}
	}

	void Update(){
		parent.Rotate(Vector3.right * Time.deltaTime);
	}
}
