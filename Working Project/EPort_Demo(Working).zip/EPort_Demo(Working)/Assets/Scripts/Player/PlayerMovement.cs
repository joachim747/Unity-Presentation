﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

	public float m_MovementSpeed;
	
	// Update is called once per frame
	void Update () {
		transform.Translate(Vector3.right * m_MovementSpeed);
		transform.Rotate(0, 2f * Input.GetAxis("Vertical"), 2f * Input.GetAxis("Horizontal"));
	}
}
