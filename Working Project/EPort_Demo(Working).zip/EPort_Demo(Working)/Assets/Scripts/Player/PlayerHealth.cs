﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour {

	public float m_StartingHealth = 100f;
	public GameObject m_Camera;
	public GameObject m_Explosion;
	public Slider m_Healthbar;

	private float m_CurrentHealth;
	private bool m_Dead;

	// Use this for initialization
	void Start () {
		m_CurrentHealth = m_StartingHealth;
		m_Dead = false;
	}
	
	public void TakeDamage(float amount){
		m_CurrentHealth -= amount;

		SetHealthUI();

		if(m_CurrentHealth <= 0f && !m_Dead){
			OnDeath();
		}
	}

	private void SetHealthUI(){
		m_Healthbar.value = m_CurrentHealth;
	}

	public bool getIfDead(){
		return m_Dead;
	}

	private void OnDeath(){
		Instantiate(m_Explosion, transform.position, transform.rotation);
		m_Camera.transform.parent = null;
		gameObject.SetActive(false);
		m_Dead = true;
	}
}
